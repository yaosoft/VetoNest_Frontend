// src/components/VideoConsultationButton.jsx
import React, { useState } from 'react';
import VideoCallModal from './VideoCallModal';
import { useVideoConsultation } from '../hooks/useVideoConsultation';

const VideoConsultationButton = ({ 
  petOwnerId, 
  veterinarianId, 
  vetName,
  ownerName = '',
  buttonText = "Video Consultation",
  className = "",
  onValidationFail,
  getAContent,
  profileId,
  navigate,
  skipValidation = false,
  consultationData = null,
  isInitiator = true
}) => {
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [validationError, setValidationError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // currentUserId  = who we are (always profileId of the logged-in user)
  // targetUserId   = who we are calling / listening for
  // Pet owner (initiator=true)  → calls the vet  → target = veterinarianUserId
  // Vet (initiator=false)       → waits for owner → target = petOwnerUserId
  const currentUserId = profileId;
  const targetUserId  = isInitiator
    ? veterinarianId                                                          // pet owner calls the vet
    : (consultationData?.carnetAnimal?.profileUser?.userId || petOwnerId);   // vet listens for the owner
  
  const {
    localStream,
    remoteStream,
    connectionStatus,
    initializeCall,
    startCall,
    endCall,
    getPeer,
    getDataChannel
  } = useVideoConsultation(
    currentUserId,
    targetUserId,
    () => { setShowVideoModal(false); },
    isInitiator
  );

  const t = (key, defaultValue) => {
    if (getAContent && typeof getAContent === 'function') {
      return getAContent(key) || defaultValue;
    }
    return defaultValue;
  };

  // Validate consultation access (only used when skipValidation is false)
  const validateConsultationAccess = async () => {
    // This function is only called when skipValidation is false (on vet profile page)
    // For now, return allowed true since we're not using it heavily
    return {
      allowed: true,
      consultation: consultationData,
      message: 'Consultation ready'
    };
  };

  const handleButtonClick = async () => {
    setIsLoading(true);
    setValidationError(null);
    
    // If validation is skipped, directly start the call
    if (skipValidation) {
      try {
        await initializeCall();
        await startCall();
        setShowVideoModal(true);
      } catch (error) {
        console.error('Error starting video call:', error);
        setValidationError(t('cmp_vetonest.com_ErrorStartingVideo_Txt', 'Failed to start video call. Please check your camera and microphone permissions.'));
      } finally {
        setIsLoading(false);
      }
      return;
    }
    
    // Otherwise, run full validation (for vet profile page)
    const validation = await validateConsultationAccess();
    
    if (!validation.allowed) {
      setValidationError(validation.message);
      if (validation.redirect && onValidationFail) {
        onValidationFail(validation.redirect);
      } else if (validation.redirect && navigate) {
        navigate(validation.redirect);
      }
      setIsLoading(false);
      return;
    }
    
    // Validation passed - initialize and start the call
    try {
      await initializeCall();
      await startCall();
      setShowVideoModal(true);
    } catch (error) {
      console.error('Error starting video call:', error);
      setValidationError(t('cmp_vetonest.com_ErrorStartingVideo_Txt', 'Failed to start video call. Please check your camera and microphone permissions.'));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <button
        onClick={handleButtonClick}
        disabled={isLoading}
        className={`btn btn-primary profileBtn ${className}`}
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '8px',
          opacity: isLoading ? 0.7 : 1,
          cursor: isLoading ? 'not-allowed' : 'pointer'
        }}
      >
        {isLoading ? (
          <>
            <span className="loading-spinner" style={{
              display: 'inline-block',
              width: '14px',
              height: '14px',
              border: '2px solid white',
              borderTop: '2px solid transparent',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite'
            }}></span>
            {t('cmp_vetonest.com_Checking_Txt', 'Checking...')}
          </>
        ) : (
          <>
            <span style={{ filter: 'brightness(0) invert(1)', display: 'inline-block' }}>🎥</span>
            {buttonText}
          </>
        )}
      </button>
      
      {validationError && (
        <div style={{ 
          marginTop: '8px', 
          color: '#ff4d4f', 
          fontSize: '12px',
          maxWidth: '250px'
        }}>
          {validationError}
        </div>
      )}
      
      {showVideoModal && (
        <VideoCallModal
          localStream={localStream}
          remoteStream={remoteStream}
          connectionStatus={connectionStatus}
          onEndCall={endCall}
          veterinarianId={veterinarianId}
          vetName={vetName}
          ownerName={ownerName}
          isInitiator={isInitiator}
          getAContent={getAContent}
          peer={getPeer ? getPeer() : null}
          dataChannel={getDataChannel ? getDataChannel() : null}
        />
      )}

      <style>
        {`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}
      </style>
    </>
  );
};

export default VideoConsultationButton;