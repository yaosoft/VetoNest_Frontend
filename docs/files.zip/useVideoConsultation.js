// src/hooks/useVideoConsultation.js
import { useEffect, useRef, useState } from 'react';
import io from 'socket.io-client';

// Load SimplePeer once
let SimplePeer = null;
let loadingPromise = null;

const loadSimplePeer = async () => {
  if (SimplePeer) return SimplePeer;
  if (loadingPromise) return loadingPromise;
  
  loadingPromise = (async () => {
    try {
      const module = await import('simple-peer');
      SimplePeer = module.default || module;
      console.log('SimplePeer loaded successfully');
      return SimplePeer;
    } catch (err) {
      console.error('Failed to load simple-peer:', err);
      throw err;
    }
  })();
  
  return loadingPromise;
};

export const useVideoConsultation = (currentUserId, targetUserId, onCallEnd, isInitiator = true) => {
  const [localStream, setLocalStream] = useState(null);
  const [remoteStream, setRemoteStream] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  const peerRef = useRef(null);
  const socketRef = useRef(null);
  const isInitiatorRef = useRef(false);
  const callInProgressRef = useRef(false);
  const dataChannelRef = useRef(null);

  // Reset call state
  const resetCallState = () => {
    callInProgressRef.current = false;
    isInitiatorRef.current = false;
    if (peerRef.current) {
      try {
        peerRef.current.destroy();
      } catch (e) {}
      peerRef.current = null;
    }
    dataChannelRef.current = null;
  };

  // Initialize connection and get media devices
  const initializeCall = async () => {
    try {
      setConnectionStatus('initializing');
      
      // Get user media
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });
      setLocalStream(stream);
      console.log('Local stream acquired');

      // Connect to signaling server
      const signalingServerUrl = process.env.REACT_APP_SIGNALING_URL || 'http://localhost:5000';
      socketRef.current = io(signalingServerUrl, {
        transports: ['websocket', 'polling']
      });

      socketRef.current.on('connect', () => {
        console.log('Connected to signaling server');
        socketRef.current.emit('register', { userId: currentUserId });
      });

      socketRef.current.on('users-online', (users) => {
        console.log('Online users:', users);
      });

      // Handle incoming call (we are the receiver)
      socketRef.current.on('incoming-call', async ({ from, offer: incomingOffer }) => {
        console.log('📞 Incoming call from:', from);

        // Ignore calls from ourselves (echo / self-call loop)
        if (String(from) === String(currentUserId)) {
          console.log('Ignoring self-originated call echo');
          return;
        }

        // If we are the initiator role, we should never receive calls
        if (isInitiator) {
          console.log('Initiator ignoring incoming call — waiting to place call only');
          return;
        }

        if (callInProgressRef.current) {
          console.log('Call already in progress, rejecting new call');
          return;
        }
        
        resetCallState();
        
        callInProgressRef.current = true;
        setConnectionStatus('ringing');
        isInitiatorRef.current = false;
        
        await loadSimplePeer();
        
        // Create peer as receiver
        const peer = new SimplePeer({
          initiator: false,
          trickle: true,
          stream: localStream
        });
        
        // Listen for data channel from caller
        peer.on('datachannel', (channel) => {
          console.log('📡 Data channel received from caller:', channel.label);
          dataChannelRef.current = channel;
          
          channel.on('open', () => {
            console.log('✅ Data channel opened (receiver)');
          });
          channel.on('close', () => {
            console.log('❌ Data channel closed (receiver)');
            dataChannelRef.current = null;
          });
          channel.on('error', (err) => {
            console.error('Data channel error:', err);
          });
        });
        
        peer.on('signal', (data) => {
          console.log('📤 Sending answer to:', from);
          socketRef.current.emit('answer-call', {
            to: from,
            answer: data
          });
        });
        
        peer.on('stream', (stream) => {
          console.log('📹 Received remote stream');
          setRemoteStream(stream);
          setConnectionStatus('connected');
        });
        
        peer.on('connect', () => {
          console.log('🔗 Peer connection established');
        });
        
        peer.on('close', () => {
          console.log('🔌 Peer connection closed');
          resetCallState();
          setRemoteStream(null);
          setConnectionStatus('disconnected');
          if (onCallEnd) onCallEnd();
        });
        
        peer.on('error', (err) => {
          console.error('❌ Peer error:', err);
          resetCallState();
          setConnectionStatus('error');
        });
        
        peer.signal(incomingOffer);
        peerRef.current = peer;
      });

      // Handle call answered (we are the caller)
      socketRef.current.on('call-answered', ({ answer }) => {
        console.log('📞 Call answered, processing answer');
        if (peerRef.current && isInitiatorRef.current) {
          try {
            peerRef.current.signal(answer);
          } catch (err) {
            console.error('Error signaling answer:', err);
          }
        }
      });

      // Handle ICE candidates
      socketRef.current.on('ice-candidate', ({ candidate }) => {
        if (peerRef.current) {
          try {
            peerRef.current.signal(candidate);
          } catch (err) {
            console.error('Error signaling ICE candidate:', err);
          }
        }
      });

      socketRef.current.on('user-not-found', ({ to }) => {
        console.error('❌ User not found:', to);
        resetCallState();
        setConnectionStatus('error');
      });

    } catch (error) {
      console.error('Failed to initialize call:', error);
      setConnectionStatus('error');
      throw error;
    }
  };

  // Start call (we are the caller)
  const startCall = async () => {
    if (callInProgressRef.current) {
      console.log('Call already in progress, ending it first');
      endCall();
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    if (!socketRef.current || !localStream) {
      await initializeCall();
    }
    
    await new Promise(resolve => setTimeout(resolve, 500));
    
    resetCallState();
    
    callInProgressRef.current = true;
    setConnectionStatus('calling');
    isInitiatorRef.current = true;
    
    try {
      console.log('📞 Starting call to:', targetUserId);
      await loadSimplePeer();
      
      const peer = new SimplePeer({
        initiator: true,
        trickle: true,
        stream: localStream
      });
      
      // Listen for data channel
      peer.on('datachannel', (channel) => {
        console.log('📡 Data channel created:', channel.label);
        dataChannelRef.current = channel;
        
        channel.on('open', () => {
          console.log('✅ Data channel opened (caller)');
        });
        channel.on('close', () => {
          console.log('❌ Data channel closed (caller)');
          dataChannelRef.current = null;
        });
        channel.on('error', (err) => {
          console.error('Data channel error:', err);
        });
      });
      
      peer.on('signal', (data) => {
        console.log('📤 Sending offer to:', targetUserId);
        socketRef.current.emit('call-user', {
          to: targetUserId,
          from: currentUserId,
          offer: data
        });
      });
      
      peer.on('stream', (stream) => {
        console.log('📹 Received remote stream');
        setRemoteStream(stream);
        setConnectionStatus('connected');
      });
      
      peer.on('connect', () => {
        console.log('🔗 Peer connection established');
      });
      
      peer.on('close', () => {
        console.log('🔌 Peer connection closed');
        resetCallState();
        setRemoteStream(null);
        setConnectionStatus('disconnected');
        if (onCallEnd) onCallEnd();
      });
      
      peer.on('error', (err) => {
        console.error('❌ Peer error:', err);
        resetCallState();
        setConnectionStatus('error');
      });
      
      peerRef.current = peer;
      
    } catch (error) {
      console.error('Failed to start call:', error);
      setConnectionStatus('error');
      resetCallState();
    }
  };

  // End call
  const endCall = () => {
    console.log('Ending call');
    resetCallState();
    setRemoteStream(null);
    setConnectionStatus('disconnected');
    
    if (socketRef.current) {
      socketRef.current.disconnect();
    }
    
    if (onCallEnd) onCallEnd();
  };

  // Get data channel for chat
  const getDataChannel = () => {
    return dataChannelRef.current;
  };

  // Get peer for chat modal
  const getPeer = () => {
    return peerRef.current;
  };

  // Cleanup
  useEffect(() => {
    return () => {
      resetCallState();
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
    };
  }, []);

  return {
    localStream,
    remoteStream,
    connectionStatus,
    initializeCall,
    startCall,
    endCall,
    getDataChannel,
    getPeer  // Make sure this is returned
  };
};