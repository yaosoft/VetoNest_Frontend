// src/components/VideoCallModal.jsx
import React, { useRef, useEffect, useState } from 'react';

const VideoCallModal = ({ 
  localStream, 
  remoteStream, 
  connectionStatus, 
  onEndCall,
  veterinarianId,
  vetName,
  ownerName = '',
  isInitiator = true,
  getAContent,
  peer
}) => {
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [showChat, setShowChat] = useState(false);
  const [dataChannelReady, setDataChannelReady] = useState(false);
  const messagesEndRef = useRef(null);
  const dataChannelRef = useRef(null);
  
  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  // Set up data channel from the peer connection
  useEffect(() => {
    if (!peer) {
      console.log('No peer available yet');
      return;
    }
    
    console.log('Setting up data channel from peer');
    
    const handleMessage = (data) => {
      try {
        const parsed = JSON.parse(data);
        if (parsed.type === 'chat') {
          setMessages(prev => [...prev, {
            text: parsed.message,
            sender: parsed.sender,
            timestamp: new Date()
          }]);
        }
      } catch (e) {
        console.error('Error parsing message:', e);
      }
    };
    
    const setupChannel = (channel) => {
      if (!channel) return;
      console.log('Setting up channel, readyState:', channel.readyState);
      dataChannelRef.current = channel;
      
      if (channel.readyState === 'open') {
        console.log('✅ Data channel already open');
        setDataChannelReady(true);
      }
      
      channel.onopen = () => {
        console.log('✅ Data channel opened');
        setDataChannelReady(true);
      };
      channel.onclose = () => {
        console.log('❌ Data channel closed');
        setDataChannelReady(false);
        dataChannelRef.current = null;
      };
      channel.onerror = (err) => {
        console.error('Data channel error:', err);
      };
      channel.onmessage = (event) => {
        handleMessage(event.data);
      };
    };
    
    // Only listen for the datachannel event — never grab _channel prematurely
    // (peer._channel is in 'connecting' state and will close immediately)
    const onDataChannel = (channel) => {
      console.log('📡 Data channel event received');
      setupChannel(channel);
    };
    peer.on('datachannel', onDataChannel);
    
    // For the initiator: SimplePeer creates the channel internally; it fires
    // 'datachannel' on itself once negotiation completes. Poll briefly to catch
    // channels that were created before this effect ran.
    const pollTimer = setTimeout(() => {
      if (!dataChannelRef.current && peer._channel && peer._channel.readyState === 'open') {
        console.log('📡 Caught open channel via poll');
        setupChannel(peer._channel);
      }
    }, 2000);
    
    return () => {
      clearTimeout(pollTimer);
      peer.off('datachannel', onDataChannel);
    };
  }, [peer]);
  
  // Send chat message
  const sendMessage = () => {
    if (!inputMessage.trim()) {
      return;
    }
    
    if (!dataChannelRef.current) {
      console.warn('No data channel available');
      return;
    }
    
    if (dataChannelRef.current.readyState !== 'open') {
      console.warn('Data channel not open. State:', dataChannelRef.current.readyState);
      return;
    }
    
    const messageData = {
      type: 'chat',
      message: inputMessage,
      sender: 'me',
      timestamp: new Date().toISOString()
    };
    
    try {
      dataChannelRef.current.send(JSON.stringify(messageData));
      console.log('📤 Message sent:', inputMessage);
      
      setMessages(prev => [...prev, {
        text: inputMessage,
        sender: 'me',
        timestamp: new Date()
      }]);
      
      setInputMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };
  
  // Handle Enter key
  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };
  
  // Format timestamp
  const formatTime = (date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  const t = (key, defaultValue) => {
    if (getAContent && typeof getAContent === 'function') {
      return getAContent(key) || defaultValue;
    }
    return defaultValue;
  };
  
  // Set up video elements
  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [localStream, remoteStream]);
  
  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0,0,0,0.9)',
      zIndex: 9999,
      display: 'flex',
      flexDirection: 'column'
    }}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '16px 24px',
        backgroundColor: '#1a1a1a',
        color: 'white'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <h3 style={{ margin: 0 }}>
            {t('cmp_vetonest.com_VideoConsultation_Title', 'Video Consultation')}
            {isInitiator
              ? vetName   && <span style={{ fontSize: '14px', marginLeft: '10px', color: '#888' }}>avec Dr. {vetName}</span>
              : ownerName && <span style={{ fontSize: '14px', marginLeft: '10px', color: '#888' }}>avec {ownerName}</span>
            }
          </h3>
          <button
            onClick={() => setShowChat(!showChat)}
            style={{
              background: showChat ? '#1890ff' : 'rgba(255,255,255,0.1)',
              border: 'none',
              color: 'white',
              padding: '6px 12px',
              borderRadius: '20px',
              cursor: 'pointer',
              fontSize: '12px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            💬 {showChat ? t('cmp_vetonest.com_HideChat_Btn', 'Hide Chat') : t('cmp_vetonest.com_ShowChat_Btn', 'Show Chat')}
            {!dataChannelReady && <span style={{ fontSize: '10px', color: '#faad14' }}>(connecting...)</span>}
          </button>
        </div>
        <span style={{
          padding: '4px 12px',
          borderRadius: '20px',
          backgroundColor: connectionStatus === 'connected' ? '#52c41a' : connectionStatus === 'connecting' ? '#1890ff' : '#faad14',
          fontSize: '12px'
        }}>
          {connectionStatus === 'connected' ? t('cmp_vetonest.com_Connected_Txt', 'Connected') : 
           connectionStatus === 'connecting' ? t('cmp_vetonest.com_Connecting_Txt', 'Connecting...') : 
           connectionStatus === 'calling' ? t('cmp_vetonest.com_Calling_Txt', 'Calling...') : 
           connectionStatus === 'ringing' ? t('cmp_vetonest.com_Ringing_Txt', 'Ringing...') :
           connectionStatus}
        </span>
        <button
          onClick={onEndCall}
          style={{
            background: 'none',
            border: 'none',
            color: 'white',
            fontSize: '24px',
            cursor: 'pointer'
          }}
        >
          ✕
        </button>
      </div>
      
      <div style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'row',
        overflow: 'hidden'
      }}>
        {/* Video area */}
        <div style={{
          flex: showChat ? 3 : 1,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          padding: '20px',
          position: 'relative'
        }}>
          <video
            ref={remoteVideoRef}
            autoPlay
            playsInline
            style={{
              width: '100%',
              height: 'auto',
              maxHeight: 'calc(100vh - 150px)',
              backgroundColor: '#333',
              borderRadius: '8px',
              objectFit: 'cover'
            }}
          />
          
          <video
            ref={localVideoRef}
            autoPlay
            playsInline
            muted
            style={{
              position: 'absolute',
              bottom: '20px',
              right: '20px',
              width: '160px',
              height: '120px',
              borderRadius: '8px',
              border: '2px solid white',
              backgroundColor: '#333',
              objectFit: 'cover'
            }}
          />
        </div>
        
        {/* Chat panel */}
        {showChat && (
          <div style={{
            width: '320px',
            backgroundColor: '#2a2a2a',
            display: 'flex',
            flexDirection: 'column',
            borderLeft: '1px solid #444'
          }}>
            <div style={{
              padding: '12px 16px',
              borderBottom: '1px solid #444',
              backgroundColor: '#333',
              color: 'white'
            }}>
              <span style={{ fontSize: '14px', fontWeight: 500 }}>
                💬 {t('cmp_vetonest.com_Chat_Title', 'Chat')}
              </span>
              <span style={{ fontSize: '11px', color: '#888', marginLeft: '8px' }}>
                {dataChannelReady ? '✅ Connected' : '⏳ Connecting...'}
              </span>
            </div>
            
            <div style={{
              flex: 1,
              overflowY: 'auto',
              padding: '16px',
              display: 'flex',
              flexDirection: 'column',
              gap: '12px'
            }}>
              {messages.length === 0 ? (
                <div style={{
                  textAlign: 'center',
                  color: '#666',
                  fontSize: '12px',
                  padding: '40px 20px'
                }}>
                  {dataChannelReady 
                    ? t('cmp_vetonest.com_NoMessages_Txt', 'No messages yet. Send a message to start the conversation.')
                    : t('cmp_vetonest.com_ConnectingChat_Txt', 'Connecting to chat...')
                  }
                </div>
              ) : (
                messages.map((msg, idx) => (
                  <div
                    key={idx}
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: msg.sender === 'me' ? 'flex-end' : 'flex-start'
                    }}
                  >
                    <div style={{
                      maxWidth: '80%',
                      padding: '8px 12px',
                      borderRadius: '12px',
                      backgroundColor: msg.sender === 'me' ? '#1890ff' : '#3a3a3a',
                      color: 'white',
                      fontSize: '13px',
                      wordBreak: 'break-word'
                    }}>
                      {msg.text}
                    </div>
                    <span style={{
                      fontSize: '10px',
                      color: '#666',
                      marginTop: '4px'
                    }}>
                      {formatTime(msg.timestamp)}
                    </span>
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>
            
            <div style={{
              padding: '12px 16px',
              borderTop: '1px solid #444',
              display: 'flex',
              gap: '8px',
              backgroundColor: '#333'
            }}>
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                disabled={!dataChannelReady}
                placeholder={dataChannelReady 
                  ? t('cmp_vetonest.com_TypeMessage_Placeholder', 'Type a message...')
                  : t('cmp_vetonest.com_WaitingForConnection_Txt', 'Waiting for connection...')
                }
                style={{
                  flex: 1,
                  padding: '8px 12px',
                  borderRadius: '20px',
                  border: '1px solid #555',
                  backgroundColor: '#2a2a2a',
                  color: 'white',
                  outline: 'none'
                }}
              />
              <button
                onClick={sendMessage}
                disabled={!dataChannelReady || !inputMessage.trim()}
                style={{
                  padding: '8px 16px',
                  borderRadius: '20px',
                  border: 'none',
                  backgroundColor: (dataChannelReady && inputMessage.trim()) ? '#1890ff' : '#555',
                  color: 'white',
                  cursor: (dataChannelReady && inputMessage.trim()) ? 'pointer' : 'not-allowed'
                }}
              >
                {t('cmp_vetonest.com_Send_Btn', 'Send')}
              </button>
            </div>
          </div>
        )}
      </div>
      
      <div style={{
        padding: '20px',
        display: 'flex',
        justifyContent: 'center',
        gap: '16px'
      }}>
        {!showChat && (
          <button
            onClick={() => setShowChat(true)}
            style={{
              padding: '12px 24px',
              backgroundColor: '#1890ff',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '16px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
          >
            💬 {t('cmp_vetonest.com_OpenChat_Btn', 'Open Chat')}
            {!dataChannelReady && <span style={{ fontSize: '10px' }}>(connecting...)</span>}
          </button>
        )}
        <button
          onClick={onEndCall}
          style={{
            padding: '12px 24px',
            backgroundColor: '#ff4d4f',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            fontSize: '16px',
            cursor: 'pointer'
          }}
        >
          {t('cmp_vetonest.com_EndCall_Btn', 'End Call')}
        </button>
      </div>
    </div>
  );
};

export default VideoCallModal;